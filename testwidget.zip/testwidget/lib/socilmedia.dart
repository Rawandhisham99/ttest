import 'package:flutter/material.dart';


class socilmedia extends StatelessWidget {


  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
       body:Container(
         child: Row(
           children: [
             Image.asset("images/fa.png"),
           ],),),



    );}}