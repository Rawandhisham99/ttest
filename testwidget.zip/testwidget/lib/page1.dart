import 'package:flutter/material.dart';


class page1 extends StatelessWidget {


  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body:Padding(padding:
      const EdgeInsets.all(30),
      child: ClipRRect(
        borderRadius:BorderRadius.circular(20),
          child: Container(
            width: 290,height: 270,
            child:
              Image.asset("images/sin.png")
          ),
      ),
    ),

    );

  }

}