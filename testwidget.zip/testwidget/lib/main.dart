import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:testwidget/page1.dart';
import 'package:testwidget/page2.dart';
import 'package:testwidget/socilmedia.dart';



void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {


  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: test(),
    );
  }
}
  class test extends StatefulWidget{

    @override
    State<StatefulWidget>createState(){

            return testState();
       }}

class testState extends State<test> {

  final _controller=PageController();

  Widget build(BuildContext context) {

        double scren=MediaQuery.of(context).size.width;
        double scren2=MediaQuery.of(context).size.height;

        return Scaffold(
        body: Center(

          child: Container(
            margin: EdgeInsets.only(top:20),
            width: 900,height: 900,
            child: Column(
              children: [Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [Image.asset("images/log.png"),
                    Icon(Icons.arrow_forward)]),
                Container(height: 250, width: 350, child: PageView(
                    controller:_controller ,
                    children: [
                     page1(),
                      page2(),
                    ]),)
                , SmoothPageIndicator(controller: _controller,
                  count: 2,
                  effect: ExpandingDotsEffect(
                      activeDotColor: Colors.blue,
                      dotColor: Colors.blue.withOpacity(.7),
                      dotHeight: 10,
                      dotWidth: 6
                  ),
                ),
                Row(
                    mainAxisAlignment:MainAxisAlignment.end ,
                    mainAxisSize: MainAxisSize.max,
                    children:[Text('"لمساهمة"الروضة وحولي% ',style: TextStyle(color:Colors.black87,
                    fontWeight:FontWeight.bold ,fontSize:15),),
                  Text('50',style: TextStyle(color:Colors.lightBlueAccent,
                      fontWeight:FontWeight.bold ,fontSize:15))
                  ,Text('خصم ',style: TextStyle(color:Colors.black87,
                      fontWeight:FontWeight.bold ,fontSize:15))]),
                Row(
                  mainAxisSize: MainAxisSize.max,
                   mainAxisAlignment:MainAxisAlignment.end ,
                    children:[Text('بروفيشنال وي كير ',style: TextStyle(color:Colors.lightBlueAccent,
                        fontWeight:FontWeight.bold ,fontSize:15)),Text('مختبر مستوصف ',
                        style: TextStyle(color:Colors.black87,
                        fontWeight:FontWeight.bold ,fontSize:15)),]),

                    Row(

                      mainAxisSize: MainAxisSize.max,
                      mainAxisAlignment:MainAxisAlignment.spaceAround  ,
                      children: [Image.asset('images/bag.png'),
                      Image.asset('images/log.png'),
                      Text('لتواصل والاستفسار',style: TextStyle(color:Colors.blueGrey
                           ,fontSize:10))],),

                    Text("92219914")
                ,Row(
                  mainAxisAlignment:MainAxisAlignment.spaceAround ,
                  children: [
                  Image.asset("images/fa.png"),
                  Image.asset("images/ins.png"),
                  Image.asset("images/tel.png"),

                ],)
              ],

            ),

          ),
        )
    );
  }

}
